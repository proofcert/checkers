class Ph
{
static int m=23;
	// TRANSCODE strings into integers
	static int String2Integer(String s)
	{
		int result=0;
		
		for(int j=0;j<s.length();j++)
			result=result*31+s.charAt(j);
			//result+=(int)s.charAt(j);
		
		return result;
	}
	
	// Note that m is a static variable
	static int HashFunction(int l)
	{return l%m;}
	
public  static  void main(String[] args)
{
String test="Frank";
System.out.println(String2Integer(test));

System.out.println(test.hashCode());
}
		
}