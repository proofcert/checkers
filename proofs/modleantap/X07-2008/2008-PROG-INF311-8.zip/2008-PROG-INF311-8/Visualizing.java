class Toto
{
double x; 
String name;

Toto(double xx, String info)
{this.x=xx; this.name=new String(info);}
};


class VisualizingMemory
{
public static void Display(Toto obj)
{
System.out.println(obj.x+":"+obj.name);
}

public static void main(String[] args)
{
int i;
Toto var=new Toto(5,"Favorite prime!");

double [] arrayx=new double[10];

Display(var);
}
	
}