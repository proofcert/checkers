import java.awt.*;
import java.applet.*;

class Point2D
{
double x,y;

Point2D()
{
this.x=300.0*Math.random();
this.y=300.0*Math.random();
}
	
}

public class AppletINF311 extends Applet {
	
final static int n=100;	
static Point2D [] set;
	
	public void init() {
		int i;
		set=new Point2D[n];
		for(i=0;i<n;i++)
			set[i]=new Point2D();
	}

	public void paint(Graphics g) {
		int i;
		
		for(i=0;i<n;i++)
		{
		int xi, yi;
		xi=(int)set[i].x; yi=(int)set[i].y;
		g.drawRect(xi, yi,1,1); 
		}	
		g.drawString("INF311!", 50, 60 );
	}
}
