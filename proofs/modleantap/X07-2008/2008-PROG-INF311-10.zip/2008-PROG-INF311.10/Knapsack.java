//
// INF311
//
class KnapSack
{
final static int n=10; // 10 objects
static int numbersol, numbercall;
static int [] weight={2,3,5,7,9,11,4,13,23,27};

static void Display(boolean [] selection, int val)
{String msg="";
	for(int i=0;i<selection.length;i++)
		{
		if (selection[i]) msg=msg+weight[i]+"+";
		}
		
		System.out.println(msg+"0="+val);
}

static void SolveKnapSack(boolean [] chosen, int goal, int i, int total)
{
numbercall++;
	
if ((i>=chosen.length)&&(total!=goal)) return;

if (total==goal) 
	{  Display(chosen, goal);
			numbersol++;
		}
else
	{
	chosen[i]=true;// add item first
	SolveKnapSack(chosen,goal,i+1,total+weight[i]);
	chosen[i]=false;  // and then remove it
	SolveKnapSack(chosen,goal,i+1,total);
	}
}


public static void main(String [] args)
{
int totalweight=51;	
numbersol=0;
numbercall=0;

System.out.println("Knapsack:");
boolean [] chosen=new boolean[n];

SolveKnapSack(chosen, totalweight, 0, 0);
System.out.println("Total number of solutions:"+numbersol);
System.out.println(" #calls="+numbercall);	
}
	
}