class Matrix
{
int col, row;

Matrix(int c, int r)
{
	this.col=c;
	this.row=r;
}

}

class Demo
{

static int CostMatrixProduct(Matrix P, Matrix Q)
{
	return P.row*Q.col*P.col;
}


static int Parentherization(int i, int j)
{
if (j-i<=1) 
	return 1;
	else
	{
	int sum=0;
	int k;
	
	for(k=i+1;k<=j-1;k++)
		{sum=sum+1+Parentherization(i,k)*Parentherization(k+1,j);}
		
		return sum;
	}
	
}

static int Parentherization(Matrix [] Chain)
{
return Parentherization(0,Chain.length-1);
}

public static void main(String [] args)
{
Matrix [] chain=new Matrix[3];

System.out.println(Parentherization(chain));

	
}

}