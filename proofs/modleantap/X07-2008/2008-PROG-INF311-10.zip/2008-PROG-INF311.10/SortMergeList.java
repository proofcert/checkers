//
// Sorting demo using linked lists as  data-structures
//
class List
{
int container;
List next;

// Constructor  List(head, tail)
List(int element, List tail)
	{
	this.container=element; 
	this.next=tail;
	}

List insert(int el)
{
return new List(el,this);	
}

int length()
{
	int result=0;
	List u=this;
	while (u!=null) 
		{u=u.next;result++;}
return result;
}

void Display()
{
List u=this;
	
while(u!=null)
	{
	System.out.print(u.container+"-->");
	u=u.next;	
	}	
System.out.println("null");
}


static void Display(List u)
{
while(u!=null)
	{
	System.out.print(u.container+"-->");
	u=u.next;	
	}	
System.out.println("null");
}

}

class SortMergeList
{

// Merge two ordered lists
static List mergeRec(List u, List v)
{
if (u==null) return v;
if (v==null) return u;

if (u.container<v.container)
	{
	u.next=mergeRec(u.next,v);
	return u;	
	}
else
	{
	v.next=mergeRec(u,v.next);
	return v;	
	}
	
}	

// Sorting procedure on linked list	
// Bugge
static List sortRec(List u)
{
int i,l=u.length(), lr;
List l1, l2, split, psplit; // references to cells

if (l<=1) 
	return u;
else
	{
	l1=u;
	
	psplit=split=u;
	i=0;lr=l/2;
	
	
	while (i<lr) 
		{i++;
		psplit=split; 
		split=split.next;}
	
	l2=split; // terminates with a null
	psplit.next=null;
	
	return mergeRec( sortRec(l1), sortRec(l2) );
	}
}	
	
public static void main(String [] args)	
{

List u=new List(3,null);
u=u.insert(2);
u=u.insert(9);
u=u.insert(6);u=u.insert(1);
u=u.insert(15);u=u.insert(17);
u=u.insert(23);u=u.insert(21);
u=u.insert(19);u=u.insert(20);

u.Display();

List sortu=sortRec(u);
System.out.println("Sorted linked list:");
sortu.Display();
}

}