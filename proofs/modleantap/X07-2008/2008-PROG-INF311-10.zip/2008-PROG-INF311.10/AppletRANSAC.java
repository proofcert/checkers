//
// Basic RANSAC
//
import java.awt.*;
import java.applet.*;

class Point2D
{
double x,y;

Point2D() // By default create a random point
{
this.x=300.0*Math.random();
this.y=300.0*Math.random();
}

Point2D(double xx, double yy) // initialize a new point
{
this.x=xx;
this.y=yy;
}

Point2D(Point2D q) // copy a point
{
this.x=q.x;this.y=q.y;	
}
	
// Apply a rigid transformation
Point2D Transformation(Point2D t, double angle)
{
double xx,yy;
xx=this.x*Math.cos(angle)+t.x;
yy=this.y*Math.sin(angle)+t.y;	
return new Point2D(xx,yy);//	
}

static int Math(Point2D[] P, Point2D[] Q, double epsilon)
{
	return -1;
}

}


class RigidTransformation
{
Point2D translation;
double angle;
double scale;
}


public class AppletRANSAC extends Applet {
	
final static int n=25;
double alpha=0.8;// 80% of points in common
double tolerance=0.0025;
Point2D t=new Point2D();
double angle=Math.random()*Math.PI;	
static Point2D [] setP;
static Point2D [] setQ;

void RANSAC()
{
int i,nbrounds=10;
int p1,p2;

for(i=0;i<nbrounds;i++)
{
p1=(int)Math.random()*n;
p2=(int)Math.random()*n;

for(j=0;j<n;j++)
	for(k=0;k<n;j++)
	{
	// Transformation
	// Test transformation	
	}
	
}
	
System.out.println("Probability of failures:");	
}

void Swap(Point2D [] set, int i, int j)
{
Point2D tmp=set[i];
set[i]=set[j];
set[j]=tmp;
}


void Shuffle(Point2D [] set)
{
int i,j,inversion;

for(inversion=0;inversion<set.length;inversion++)
{
i=(int)(Math.random()*set.length);
j=(int)(Math.random()*set.length);
Swap(set,i,j);
}
	
}

	
	public void init() {
		// Two random point sets that match alpha percent
		int i,j;
		setP=new Point2D[n];
		setQ=new Point2D[n];
		j=(int)(alpha*n);
		
		for(i=0;i<j;i++)
			{setP[i]=new Point2D();
			setQ[i]=new Point2D(setP[i].x+tolerance,setP[i].y+tolerance);
			}
		
		for(i=j;i<n;i++)
		{
			setP[i]=new Point2D();
			setQ[i]=new Point2D();
		}
		Shuffle(setP); 
		Shuffle(setQ);
		// Apply a transformation to point set Q
		for(i=0;i<j;i++)
			{
			setP[i]=setP[i].Transformation(t,angle);	
				}
				}
			
// To draw a point, draw a square of side 1
	public void paint(Graphics g) {
		int i, xi, yi;
		
		g.setColor(Color.red);
		for(i=0;i<n;i++)
		{
	
		xi=(int)setP[i].x; yi=(int)setP[i].y;
		g.drawRect(xi, yi,1,1); 
		}
		
		g.setColor(Color.blue);
		for(i=0;i<n;i++)
		{
		xi=(int)setQ[i].x; yi=(int)setQ[i].y;
		g.drawRect(xi, yi,1,1); 
		}	
		
			
	
	}
}
