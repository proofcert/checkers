class Point2D
{double x,y;
// Constructor
Point2D(double xi, double yi)
{this.x=xi;this.y=yi;	}
// Overrides default method
public String toString()
{return "["+x+" "+y+"]"; }
}

class SuperClass
{
public static void main(String [] a)
{
  Point2D myPoint=new Point2D(Math.PI, Math.E);
  System.out.println("Point:"+myPoint);
}
}